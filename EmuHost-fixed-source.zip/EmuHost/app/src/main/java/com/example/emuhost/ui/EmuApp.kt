package com.example.emuhost.ui

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.emuhost.data.*
import com.example.emuhost.engine.QemuLauncher
import com.example.emuhost.engine.VmService
import kotlin.math.roundToInt

@Composable
fun EmuApp(ctx: Context) {
    val nav = rememberNavController()
    val repo = remember { VmRepository(ctx) }
    val vms = remember { mutableStateListOf<Vm>().apply { addAll(repo.load()) } }
    val logs = remember { mutableStateMapOf<String, String>() }

    NavHost(nav, "home") {
        composable("home") {
            HomeScreen(vms, logs, ctx,
                onAdd = { nav.navigate("create") },
                onDelete = { vms.remove(it); repo.save(vms) })
        }
        composable("create") {
            CreateScreen(onBack = { nav.popBackStack() }) { vm ->
                vms.add(vm.copy(vncPort = 5901 + vms.size)); repo.save(vms); nav.popBackStack()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vms: List<Vm>, logs: MutableMap<String, String>, ctx: Context, onAdd: () -> Unit, onDelete: (Vm) -> Unit) {
    var running by remember { mutableStateOf(setOf<String>()) }
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        topBar = { LargeTopAppBar(title = { Text("Virtual machines") }, scrollBehavior = scroll) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text("New VM") })
        }
    ) { pad ->
        if (vms.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Computer, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    Text("No virtual machines yet", style = MaterialTheme.typography.titleMedium)
                    Text("Tap New VM to add an Android or PC image", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vms, key = { it.id }) { vm ->
                val isRun = vm.id in running
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (vm.type == GuestType.ANDROID) Icons.Default.Android else Icons.Default.DesktopWindows, null,
                                tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(vm.name, style = MaterialTheme.typography.titleMedium)
                                Text(vm.androidVersion?.label ?: vm.type.label, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { onDelete(vm) }) { Icon(Icons.Default.Delete, "Delete") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip({}, { Text("${vm.ramMb} MB") })
                            AssistChip({}, { Text("${vm.cores} cores") })
                            AssistChip({}, { Text(vm.arch.label) })
                        }
                        logs[vm.id]?.takeIf { it.isNotBlank() }?.let {
                            Text(it.takeLast(300), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        if (!isRun) FilledTonalButton(onClick = {
                            ctx.startForegroundService(Intent(ctx, VmService::class.java))
                            QemuLauncher.start(ctx, vm) { line -> logs[vm.id] = (logs[vm.id] ?: "") + line + "\n" }
                                .onSuccess { running = running + vm.id }
                                .onFailure { logs[vm.id] = it.message ?: "Failed" }
                        }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Start") }
                        else FilledTonalButton(onClick = { QemuLauncher.stop(vm.id); running = running - vm.id }) {
                            Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("Stop")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScreen(onBack: () -> Unit, onSave: (Vm) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(GuestType.ANDROID) }
    var av by remember { mutableStateOf(AndroidVersion.A9) }
    var arch by remember { mutableStateOf(Arch.X86_64) }
    var ram by remember { mutableFloatStateOf(2048f) }
    var cores by remember { mutableFloatStateOf(2f) }
    var disk by remember { mutableStateOf<String?>(null) }
    var diskName by remember { mutableStateOf("") }
    var isIso by remember { mutableStateOf(false) }
    var newDisk by remember { mutableFloatStateOf(16f) }
    var accel by remember { mutableStateOf(Accel.TCG) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            disk = it.toString(); diskName = it.lastPathSegment ?: "image"
            isIso = diskName.endsWith(".iso", true)
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("New virtual machine") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

            Text("Guest type", style = MaterialTheme.typography.labelLarge)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                GuestType.entries.forEachIndexed { i, t ->
                    SegmentedButton(type == t, { type = t }, SegmentedButtonDefaults.itemShape(i, GuestType.entries.size)) { Text(if (t == GuestType.ANDROID) "Android" else "PC OS") }
                }
            }
            if (type == GuestType.ANDROID) {
                Text("Android version", style = MaterialTheme.typography.labelLarge)
                Column { AndroidVersion.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach {
                        FilterChip(av == it, { av = it }, { Text(it.label.substringBefore(" (")) })
                    } }
                } }
                if (av == AndroidVersion.A10) Text("Android 10 x86 builds are community/unofficial and may be unstable.", style = MaterialTheme.typography.bodySmall)
            }
            Text("Architecture", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Arch.entries.forEach { FilterChip(arch == it, { arch = it }, { Text(it.label) }) }
            }

            Text("RAM: ${ram.roundToInt()} MB", style = MaterialTheme.typography.labelLarge)
            Slider(ram, { ram = it }, valueRange = 512f..6144f, steps = 10)
            Text("CPU cores: ${cores.roundToInt()}", style = MaterialTheme.typography.labelLarge)
            Slider(cores, { cores = it }, valueRange = 1f..8f, steps = 6)

            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp))
                Text(if (disk == null) "Choose .img / .iso / .qcow2" else diskName)
            }
            if (isIso) {
                Text("New disk size: ${newDisk.roundToInt()} GB (installer ISO detected)", style = MaterialTheme.typography.labelLarge)
                Slider(newDisk, { newDisk = it }, valueRange = 4f..64f)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Use KVM acceleration"); Text("Only works if the device exposes /dev/kvm", style = MaterialTheme.typography.bodySmall)
                }
                Switch(accel == Accel.KVM, { accel = if (it) Accel.KVM else Accel.TCG })
            }
            Button(
                enabled = name.isNotBlank() && disk != null,
                onClick = {
                    onSave(Vm(name = name.trim(), type = type, androidVersion = if (type == GuestType.ANDROID) av else null,
                        arch = arch, ramMb = ram.roundToInt(), cores = cores.roundToInt(), diskUri = disk!!,
                        isCdrom = isIso, newDiskGb = if (isIso) newDisk.roundToInt() else 0, accel = accel))
                }, modifier = Modifier.fillMaxWidth()
            ) { Text("Create") }
        }
    }
}
