# EmuHost

EmuHost is a Kotlin + Jetpack Compose front-end for managing QEMU virtual-machine configurations on Android.

## Build an APK with GitHub Actions

1. Upload the contents of this project to a GitHub repository (the `.github` folder must be included).
2. Open the repository's **Actions** tab.
3. Select **Build EmuHost APK** and choose **Run workflow**, or push a commit to `main`/`master`.
4. When the run succeeds, download the `EmuHost-debug-apk` artifact and extract the APK.

The workflow uses Java 17, Android SDK setup, and Gradle 8.7; it does not require a checked-in Gradle wrapper.

## Important limitations

A successful APK build does **not** mean that guest operating systems can boot. QEMU is not bundled in this source project. To run VMs, compatible Android/ARM64 QEMU executable binaries and any required firmware must be built and added. The current app does not include an integrated VNC display screen; its VM configuration UI alone is not a complete emulator.

Expected QEMU binary names are defined in `data/Vm.kt` and referenced by `engine/QemuLauncher.kt`. Do not rename arbitrary desktop QEMU binaries and expect them to work on Android; they must be built for Android/ARM64 and have compatible dependencies.
